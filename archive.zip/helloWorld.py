#name = "habib"
def main(name):
    text = 'my name is {}'.format(name)
    print(text)
    return text

main('moussa')


    #x, y = 1000, 1000
    #name = input("what is your name? ")
    #print("my name is: "  +name)


    #global name 
    #st  = "x is greater" if (x < y) else "y is much greater than x"

    #if name != "":
        #del name
        #name = "Ali"
        #print("hi im here " + name)
        #print(st)


#if __name__ == "__main__":
