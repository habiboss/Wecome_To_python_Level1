x = 1
sum = 0
while x < 10:
    sum += 1
    x = x + 1
    print(str(sum) + " " + str(x))

product = 1
while x < 10:
    product *= x
    x += 1
    print(sum, product)